<?php
			
			$success_url = './success';
			
			$server = $_SERVER['HTTP_HOST'];
			$name = $_POST['name'];
			
			if (isset($_POST['phone'])) {$phone = $_POST['phone'];}
			if (empty($phone))
			{
				echo "I can not send!";
				exit;
			}
			$ip = $_SERVER['REMOTE_ADDR'];
			if (isset($_POST['tovar_id1'])) {$theme = '<br><strong>Товар:</strong> '.($_POST["tovar_id1"]);}
			if (isset($_POST['tovar_id2'])) {$theme .= '<br><strong>Цвет:</strong> '.($_POST["tovar_id2"]);}
			if (isset($_POST['tovar_id3'])) {$theme .= '<br><strong>Набор пластика:</strong> '.($_POST["tovar_id3"]);}
			
			 
			
			
			$mail_header = "MIME-Version: 1.0\r\n";
			$mail_header.= "Content-type: text/html; charset=UTF-8\r\n";
			$mail_header.= "From: $server <informer@$server>\r\n";
			$mail_header.= "Reply-to: Reply to Name <reply@$server>\r\n";
			
			$to = "dmitrijschuljak@gmail.com";
			 
			$subject = "Заявка с сайта: $server";
			
			$message = "  $theme<br><strong>Имя:</strong> $name<br><strong>Телефон:</strong> $phone <br><strong>Время заказа:</strong> ".date("m.d.Y H:i:s")." <br><strong>IP покупателя:</strong> $ip   ";
			if (mail($to,$subject,$message,$mail_header))
			header('Location: '.$success_url);
			else echo 'Oshibka otpravki - otklyuchena funkciya (php mail). Obratites v podderzhku xostinga';
?>